<?
$arTemplate = array (
  'NAME' => 'Посадочная страница',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>